#include "rt_ehtercat.hpp"
#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"

#define PORT "enp5s0"
#define PI              3.1415926535898
int returnValue = 0;
char IOmap[4096];
double act_position[12];
double act_position_array[12][50];
double act_position_filtered[12];
double act_position_filtered_array[12][2];

double target_velocity[12];//单位：弧�?rad
double target_velocity_array[12][2];
double act_velocity[12];
double act_velocity_array[12][20];
double act_velocity_filtered[12];

double target_torque[12];
double target_GRF[12];//各个关节当前�?标的地反力补偿目标量，以供进入四足支撑相时�?�当前量进�?�迭代逼近
double act_torque[12];

double target_acc[12];
double act_acc[12];//angular_acceleration
double act_acc_array[12][50];
double act_acc_filtered[12];

double target_direction[12];//关节应�?��?�运动的方向，与坐标系方向一�?
double act_direction[12];
bool stop_all; 
//键盘检测
#define TTY_PATH            "/dev/tty"
#define STTY_US             "stty raw -echo -F "
#define STTY_DEF            "stty -raw echo -F "
int get_char()
{
    fd_set rfds;
    struct timeval tv;
    int ch = 0;
    FD_ZERO(&rfds);
    FD_SET(0, &rfds);
    tv.tv_sec = 0;
    tv.tv_usec = 10; //设置等待超时时间
    if (select(1, &rfds, NULL, NULL, &tv) > 0) //检测键盘是否有输入
    {
        ch = getchar(); 
    }
    return ch;
}
// detect ctr c and trigger the termination of all threads
void ctrl_c_function(int sig){
   stop_all = true;
   (void)signal(SIGINT, SIG_DFL);
}
void tf_current(float current, uint8 *b0, uint8 *b1){
  // 1A @ rate current: 10A , 100
  // 10A @ rate current: 10A , 1000
  int rate(0);
  current = current/2.0;
  if(current>=0){
    rate = current * 100;
  }
  else{
    rate = 65536 + (int) (current * 100);
  }
  // printf("rate: %d ",rate);
  *b0 = rate%256; //低八位
  *b1 = rate/256; //高八位 
}
static int config_check(int wkc){
    int success = 0;
    if(wkc==1)
    {
        returnValue ++;
        // printf("config success, returnValue = %d\n", returnValue);
        success = 1;
    }
    else
    {
        /* code */
        // printf("config error, returnValue = %d\n", returnValue);
        success = 0;
    }
    return success;
}
void process_data_config()
{
	int size = 2;
	uint8_t     b;
	uint16_t w,ind;
	uint32_t dw;
	
	for(int slave = 1; slave <= *ecx_context.slavecount; slave++)
	{
		//rpdo------------
		//1c12.0
		b = 0;
		ec_SDOwrite(slave, 0x1c12, 0x00, FALSE, sizeof(b), &b, EC_TIMEOUTRXM);
		w = htoes(0x1600);
		ec_SDOwrite(slave, 0x1c12, 0x01, FALSE, sizeof(w), &w, EC_TIMEOUTRXM);
		
		//1600
		ind = 0;
		b = 0;
		ec_SDOwrite(slave, 0x1600, 0, FALSE, sizeof(b), &b, EC_TIMEOUTRXM);
		dw = htoel(0x60710010U);//6040h(控制字)
		ec_SDOwrite(slave, 0x1600, ++ind, FALSE, sizeof(dw), &dw, EC_TIMEOUTRXM);
		dw = htoel(0x60400010U);//607Ah(目标位置)
		ec_SDOwrite(slave, 0x1600, ++ind, FALSE, sizeof(dw), &dw, EC_TIMEOUTRXM);
		dw = htoel(0x60600008U);//607Ch(原点偏移量)
		ec_SDOwrite(slave, 0x1600, ++ind, FALSE, sizeof(dw), &dw, EC_TIMEOUTRXM);
		dw = htoel(0x00000008U);//607Ch(原点偏移量)
		ec_SDOwrite(slave, 0x1600, ++ind, FALSE, sizeof(dw), &dw, EC_TIMEOUTRXM);
		dw = htoel(0x60870020U);//607Ch(原点偏移量)
		ec_SDOwrite(slave, 0x1600, ++ind, FALSE, sizeof(dw), &dw, EC_TIMEOUTRXM);
		b = ind;
		ec_SDOwrite(slave, 0x1600, 0, FALSE, sizeof(b), &b, EC_TIMEOUTRXM);
 
		//1c12.0
		b = 1;
		ec_SDOwrite(slave, 0x1c12, 0x00, FALSE, sizeof(b), &b, EC_TIMEOUTRXM);
		
		//tpdo-------------
		//1c13.0
		b = 0;
		ec_SDOwrite(slave, 0x1c13, 0x00, FALSE, sizeof(b), &b, EC_TIMEOUTRXM);
		w = htoes(0x1a00);
		ec_SDOwrite(slave, 0x1c13, 0x01, FALSE, sizeof(w), &w, EC_TIMEOUTRXM);
		
		//1a00
		ind = 0;
		b = 0;
		ec_SDOwrite(slave, 0x1a00, 0, FALSE, sizeof(b), &b, EC_TIMEOUTRXM);
		dw = htoel(0x60640020U);//603Fh(错误码)
		ec_SDOwrite(slave, 0x1a00, ++ind, FALSE, sizeof(dw), &dw, EC_TIMEOUTRXM);
		dw = htoel(0x606c0020U);//6041h(状态字)
		ec_SDOwrite(slave, 0x1a00, ++ind, FALSE, sizeof(dw), &dw, EC_TIMEOUTRXM);
		dw = htoel(0x60770010U);//6064h(位置反馈)
		ec_SDOwrite(slave, 0x1a00, ++ind, FALSE, sizeof(dw), &dw, EC_TIMEOUTRXM);
		dw = htoel(0x60410010U);//6064h(位置反馈)
		ec_SDOwrite(slave, 0x1a00, ++ind, FALSE, sizeof(dw), &dw, EC_TIMEOUTRXM);
		dw = htoel(0x60610008U);//6064h(位置反馈)
		ec_SDOwrite(slave, 0x1a00, ++ind, FALSE, sizeof(dw), &dw, EC_TIMEOUTRXM);
		dw = htoel(0x00000008U);//6064h(位置反馈)
		ec_SDOwrite(slave, 0x1a00, ++ind, FALSE, sizeof(dw), &dw, EC_TIMEOUTRXM);
		b = ind;
		ec_SDOwrite(slave, 0x1a00, 0, FALSE, sizeof(b), &b, EC_TIMEOUTRXM);
 
		//1c13.0
		b = 1;
		ec_SDOwrite(slave, 0x1c13, 0x00, FALSE, sizeof(b), &b, EC_TIMEOUTRXM);
	}
}
void io_config(){
    //Input start
    /*1a00h mapping start*/
    int cnt=0;
    uint32 sdo_data32=0;
    uint16 sdo_data16=0;
    uint8 sdo_data8=0;
    void * p32 = (void *)(&sdo_data32);
    void * p16 = (void *)(&sdo_data16);
    void * p8 = (void *)(&sdo_data8);
    // void * p = (void *)(&uDataValue);

    for(cnt = 1; cnt <= ec_slavecount ; cnt++)
    {
        sdo_data8=0x00U;
        int suc = 0;
        do{
            suc = config_check(ec_SDOwrite(cnt, 0x1a00U, 0U, FALSE, 1, p8, EC_TIMEOUTRXM));//😁重要函数 对从站邮箱进行配置(多次)
        }  while(suc!=1) ;
    }

    for(cnt = 1; cnt <= ec_slavecount ; cnt++)
    {   
                                /*这一块是TxPD0映射*/

        //用SDO完成对PDO的映射 将字典表中0x60640020U映射到 PDO 中的 0x1a00U 1U 
        sdo_data32 = 0x60640020U;                 //position actual value
        config_check(ec_SDOwrite(cnt, 0x1a00U, 1U, FALSE, 4, p32, EC_TIMEOUTRXM));
        sdo_data32 = 0x606c0020U;                 //velocity actual value
        config_check(ec_SDOwrite(cnt, 0x1a00U, 2U, FALSE, 4, p32, EC_TIMEOUTRXM));
        sdo_data32 = 0x60770010U;                 //torque actual value
        config_check(ec_SDOwrite(cnt, 0x1a00U, 3U, FALSE, 4, p32, EC_TIMEOUTRXM));
        sdo_data32 = 0x60410010U;                 //status word
        config_check(ec_SDOwrite(cnt, 0x1a00U, 4U, FALSE, 4, p32, EC_TIMEOUTRXM));
        // sdo_data32=0x22050110;	//Analog input
        // config_check(ec_SDOwrite(cnt, 0x1a00U, 5U, FALSE, 4, p32, EC_TIMEOUTRXM));
        sdo_data32 = 0x60610008U;                 //operation mode display
        config_check(ec_SDOwrite(cnt, 0x1a00U, 5U, FALSE, 4, p32, EC_TIMEOUTRXM));
        sdo_data32 = 0x00000008U;                 //operation mode display
        config_check(ec_SDOwrite(cnt, 0x1a00U, 6U, FALSE, 4, p32, EC_TIMEOUTRXM));
    }

    for(cnt = 1; cnt <= ec_slavecount ; cnt++)
    {
        sdo_data8 = 0x06U;
        config_check(ec_SDOwrite(cnt, 0x1a00U, 0U, FALSE, 1, p8, EC_TIMEOUTRXM)); 
    }
    /*1a00h mapping end*/

    //Output start

    /*1600h mapping start*//*这一块是RxPD0映射*/
    for(cnt = 1; cnt <= ec_slavecount ; cnt++)
    {
        sdo_data8=0x00;
        config_check(ec_SDOwrite(cnt, 0x1600U, 0U, FALSE, 1, p8, EC_TIMEOUTRXM)); 
    }
    for(cnt = 1; cnt <= ec_slavecount ; cnt++)
    {
        // sdo_data32 = 0x607a0020U;                 //Target position
        // config_check(ec_SDOwrite(cnt, 0x1600U, 1U, FALSE, 4, p32, EC_TIMEOUTRXM));
        // sdo_data32 = 0x60ff0020U;                 //Target velocity
        // config_check(ec_SDOwrite(cnt, 0x1600U, 2U, FALSE, 4, p32, EC_TIMEOUTRXM));
        // sdo_data32 = 0x60B10020U;                 //Velocity Offset
        // config_check(ec_SDOwrite(cnt, 0x1600U, 3U, FALSE, 4, p32, EC_TIMEOUTRXM));
        sdo_data32 = 0x60710010U;                 //Target torque
        config_check(ec_SDOwrite(cnt, 0x1600U, 1U, FALSE, 4, p32, EC_TIMEOUTRXM));
        // sdo_data32 = 0x60B20010U;                  //Torque offset
        // config_check(ec_SDOwrite(cnt, 0x1600U, 5U, FALSE, 4, p32, EC_TIMEOUTRXM));
        sdo_data32 = 0x60400010U;                 //Control word
        config_check(ec_SDOwrite(cnt, 0x1600U, 2U, FALSE, 4, p32, EC_TIMEOUTRXM));
        sdo_data32 = 0x60600008U;                 //Operation mode
        config_check(ec_SDOwrite(cnt, 0x1600U, 3U, FALSE, 4, p32, EC_TIMEOUTRXM));
        sdo_data32 = 0x00000008U;                 //Operation mode
        config_check(ec_SDOwrite(cnt, 0x1600U, 4U, FALSE, 4, p32, EC_TIMEOUTRXM));
        sdo_data32 = 0x60870020U;                 //torque slope
        config_check(ec_SDOwrite(cnt, 0x1600U, 5U, FALSE, 4, p32, EC_TIMEOUTRXM));
    }
    for(cnt = 1; cnt <= ec_slavecount ; cnt++){
        sdo_data8 = 5U;
        config_check(ec_SDOwrite(cnt, 0x1600U, 0U, FALSE, 1, p8, EC_TIMEOUTRXM));
    }
    /*1600h mapping end*/

    /*1c12h mapping start*/ //配置了邮箱通道的映射
    for(cnt = 1; cnt <= ec_slavecount ; cnt++)
    {
        sdo_data8 = 0x00U;
        config_check(ec_SDOwrite(cnt, 0x1c12U, 0U, FALSE, 1, p8, EC_TIMEOUTRXM));
    }
    for(cnt = 1; cnt <= ec_slavecount ; cnt++)
    {
        sdo_data16 = 0x1600U;
        config_check(ec_SDOwrite(cnt, 0x1c12U, 1U, FALSE, 2, p16, EC_TIMEOUTRXM));
    }
    for(cnt = 1; cnt <= ec_slavecount ; cnt++)
    {
        sdo_data8 = 0x01U;
        config_check(ec_SDOwrite(cnt, 0x1c12U, 0U, FALSE, 1, p8, EC_TIMEOUTRXM));
    }
    /*1c12h mapping end*/

    /*1c13h mapping start*/
    for(cnt = 1; cnt <= ec_slavecount ; cnt++)
    {
        sdo_data8 = 0x00U;
        config_check(ec_SDOwrite(cnt, 0x1c13U, 0U, FALSE, 1, p8, EC_TIMEOUTRXM));
    }
    for(cnt = 1; cnt <= ec_slavecount ; cnt++)
    {
        sdo_data16 = 0x1a00U;
        config_check(ec_SDOwrite(cnt, 0x1c13U, 1U, FALSE, 2, p16, EC_TIMEOUTRXM));
    }
    for(cnt = 1; cnt <= ec_slavecount ; cnt++)
    {
        sdo_data8 = 0x01U;
        config_check(ec_SDOwrite(cnt, 0x1c13U, 0U, FALSE, 1, p8, EC_TIMEOUTRXM));
    }
    /*1c13h mapping end*/

    /*1c32h 1c33h config start*/
    // for(cnt = 1; cnt <= ec_slavecount ; cnt++)
    // {
    //     sdo_data8 = 0x00U;
    //     config_check(ec_SDOwrite(cnt, 0x1c32U, 0U, FALSE, 1, p8, EC_TIMEOUTRXM));
    //     sdo_data8 = 0x00U;
    //     config_check(ec_SDOwrite(cnt, 0x1c33U, 0U, FALSE, 1, p8, EC_TIMEOUTRXM));
    // }
    // for(cnt = 1; cnt <= ec_slavecount ; cnt++)
    // {
    //     sdo_data8 = 0x02U;
    //     config_check(ec_SDOwrite(cnt, 0x1c32U, 1U, FALSE, 1, p8, EC_TIMEOUTRXM));
    //     sdo_data8 = 0x02U;
    //     config_check(ec_SDOwrite(cnt, 0x1c33U, 1U, FALSE, 1, p8, EC_TIMEOUTRXM));
    // }
    // for(cnt = 1; cnt <= ec_slavecount ; cnt++)
    // {
    //     sdo_data8 = 0x01U;
    //     config_check(ec_SDOwrite(cnt, 0x1c32U, 0U, FALSE, 1, p8, EC_TIMEOUTRXM));
    //     sdo_data8 = 0x01U;
    //     config_check(ec_SDOwrite(cnt, 0x1c33U, 0U, FALSE, 1, p8, EC_TIMEOUTRXM));
    // }
    /*1c32h 1c33h config end*/

    //end
    // printf("returnValue = %d\n", returnValue);
    printf("++ io config complete! \n");
}
void motor_driver_config( bool *stop_all){
    /* initialise SOEM, bind socket to ifname */
    // char IOmap[4096];
    if (ec_init(PORT))
    {
        std::cout << "============================================================================= \n";
        std::cout << "++ Motor driver config \n";
        std::cout << "++ ec_init on " << PORT << " succeeded." << std::endl;
        if ( ec_config_init(FALSE) > 0 )
        {
            std::cout << "++ " << ec_slavecount << " slaves found and configured." << std::endl;
            // if(MOTOR_NUM!=ec_slavecount){
            //   std::cout << "controlled motor not match ec_slavecount\n";
            //   *stop_all = true;
            // }
            // if(MOTOR_NUM!=ec_slavecount){
            //   std::cout << "controlled motor not match ec_slavecount\n";
            // }
            // config slave PDO mapping
            // if((ec_slavecount > 1))
            // {
            //     for(int slc = 1; slc <= ec_slavecount; slc++){
            //       ec_slave[slc].PO2SOconfig = &DIGEsetup;
            //     }
            // }
            // io_config();
            process_data_config();
            ec_config_map(IOmap);
            ec_configdc(); 
            /* wait for all slaves to reach SAFE_OP state */
            ec_statecheck(0, EC_STATE_SAFE_OP,  EC_TIMEOUTSTATE);
            
            //config sync manager
            // for(int i=1;i<=ec_slavecount;i++)
            // {
            //   ec_dcsync0(i, TRUE, SYNC0TIME, 0); // SYNC0 on slave 1
            // }
            
            ec_readstate();//(基本环节)获取从站的基本信息 具体包括？
            for(int cnt = 1; cnt <= ec_slavecount ; cnt++)
            {
                std::cout << "++ Slave:" << cnt << ", "
                            << "Name:" << ec_slave[cnt].name << ", "
                            << "Output size: " << ec_slave[cnt].Obits << "bits, "
                            << "Input size: " << ec_slave[cnt].Ibits << "bits, "
                            << "State: " << ec_slave[cnt].state << ", "
                            << "delay: " << ec_slave[cnt].pdelay << ", "<<std::endl;
                            // << "has DC: " << ec_slave[cnt].hasdc << std::endl;
            }
            std::cout << "++ Request operational state for all slaves\n";

            /* send one processdata cycle to init SM in slaves */
            ec_send_processdata();
            ec_receive_processdata(EC_TIMEOUTRET);

            ec_slave[0].state = EC_STATE_OPERATIONAL;
            /* request OP state for all slaves */
            ec_writestate(0);
            /* wait for all slaves to reach OP state */
            ec_statecheck(0, EC_STATE_OPERATIONAL,  EC_TIMEOUTSTATE);
            
            if (ec_slave[0].state == EC_STATE_OPERATIONAL ){//只用验证选一个从机？？
                std::cout << "++ All slaves reach OP state! \n";
            }
            else{
                std::cout << "Not all slaves reached operational state.\n";
            }  
        }
    }else{
      *stop_all=true;
      printf("ecat error\n");
      exit(-1);
    }
    std::cout << "++ Motor drivers config complete! \n";
    std::cout << "============================================================================= \n";
}

void init_motor(){
  uint8_t loop_flag = 1;
  uint8_t step = 0;
  while(loop_flag)
  { 
    switch (step)
    {
      case 0:
           printf ("step:%d, status 1: %02X \n", step, ec_slave[1                                                                            ].inputs[10]);
          for(int cnt = 1; cnt <= ec_slavecount ; cnt++)
          {
            ec_slave[cnt].outputs[2] = 0x06; // control word 
            ec_slave[cnt].outputs[4] = 0x04; // mode of operation
            ec_slave[cnt].outputs[6] = 0xFF; // 1st byte of torque slope (integrater32)

            ec_slave[cnt].outputs[7] = 0x1F;//
            ec_slave[cnt].outputs[1] = 0x00; // 2nd byte of target torque ( integer16)
            ec_slave[cnt].outputs[0] = 0x00; // 1st byte of target torque (integer16)
          }
            ec_send_processdata();
            ec_receive_processdata(EC_TIMEOUTRET);
            step = 1;
            break;
      case 1:
            // ec_send_processdata();
            // ec_receive_processdata(EC_TIMEOUTRET);
           printf ("step:%d, status 1: %02X \n", step, ec_slave[1].inputs[10]);
            if(0x31 == ec_slave[1].inputs[10])
            {
              for(int cnt = 1; cnt <= ec_slavecount ; cnt++)
              {
                ec_slave[cnt].outputs[2] = 0x07;
              }
                ec_send_processdata();
                ec_receive_processdata(EC_TIMEOUTRET);
                step = 2;
                // usleep(100000);
            }
            else{step = 0;}
              break;
            case 2:
                ec_send_processdata();
                ec_receive_processdata(EC_TIMEOUTRET);
               printf ("step:%d, status 1: %02X \n", step, ec_slave[1].inputs[10]);
                if(0x33 == ec_slave[1].inputs[10])
                {
                  for(int cnt = 1; cnt <= ec_slavecount ; cnt++)
                  {
                    ec_slave[cnt].outputs[2] = 0x0F;
                  }
                    ec_send_processdata();
                    ec_receive_processdata(EC_TIMEOUTRET);
                    step = 3;
                    // usleep(100000);
                }
                break;

            case 3:
                // ec_send_processdata();
                ec_receive_processdata(EC_TIMEOUTRET);
               printf ("step:%d, status 1: %02X \n", step, ec_slave[1].inputs[10]);
                loop_flag = 0;
                if(0x37 == ec_slave[1].inputs[10])
                {
                  // printf ("step:%d, %X\n", step, ec_slave[1].inputs[10]);
                  step = 4;
                  loop_flag = 0;
                }
                usleep(100);
                break;
            
            default:
                break;
            }
            usleep(100);
        }
        std::cout << "++ Motors are enabled...\n";
}
void 
run_ecat(float current)
{
    static float tmp_current = 4;
    std::cout << "Ethercat thread gets started !" << std::endl;

    //for keyboard
    // int ch = 0;
    // system(STTY_US TTY_PATH);
    //
    int ct = 0;
    double remaining_time = 0.0;
    // struct timespec rem, req = {0, remaining_time};
  
    uint8 *p[12];
    for(int cnt = 1; cnt <= ec_slavecount ; cnt++)
    {
      p[cnt-1]= ec_slave[cnt].outputs;
    }
    uint32 tmp[12];

    init_motor(); // enable the motors ready for running.
    while(1){
      // update ethercat data
      ec_receive_processdata(EC_TIMEOUTRET); 
      ec_send_processdata();     
      for(int cnt = 1; cnt <= ec_slavecount ; cnt++)
      { 
        /*for keyboard*/    
        // ch = get_char();
        // if(ch=='f'){   
        //   current++;
        //   printf("current ++\n\r");
        //   break;
        // }
        // else if(ch=='b'){
        //   current--;
        //   printf("current --\n\r");
        // }  
        //
        tmp[cnt-1] = (uint32)ec_slave[cnt].inputs[0] + ((uint32)ec_slave[cnt].inputs[1])*256 + ((uint32)ec_slave[cnt].inputs[2])*65536 + ((uint32)ec_slave[cnt].inputs[3])*16777216;
        act_position[cnt-1] = tmp[cnt-1]*360.0/16777216;
        if(act_position[cnt-1] > 10000){act_position[cnt-1] = (tmp[cnt-1] - 4294967296)*360.0/131072;}
        
        // tmp[cnt-1] = (uint32) ec_slave[cnt].inputs[4] + ((uint32) ec_slave[cnt].inputs[5])*256 + ((uint32) ec_slave[cnt].inputs[6])*65536 + ((uint32)ec_slave[cnt].inputs[7])*16777216;
        // act_velocity[cnt-1] = tmp[cnt-1] * 60.0/131072; // unit of the velocity is rpm for the motor. Gear ratio is taken into account. The raw data unit is pulse/s.
        // if(act_velocity[cnt-1] > 100000){act_velocity[cnt-1] = act_velocity[cnt-1] - 4294967296*60.0/131072;}
        // act_velocity[cnt-1]=act_velocity[cnt-1]*PI/(30*GEAR_RATIO);// rad/s
        //位置�?分求出速度
        act_position_filtered_array[cnt-1][0]=act_position_filtered_array[cnt-1][1];
        act_position_filtered_array[cnt-1][1]=act_position_filtered[cnt-1];
        act_velocity[cnt-1]=(act_position_filtered_array[cnt-1][1]-act_position_filtered_array[cnt-1][0])/0.00026;
        act_velocity[cnt-1]=act_velocity[cnt-1]*PI/180;
        
        act_torque[cnt-1] = ( ec_slave[cnt].inputs[8] + ec_slave[cnt].inputs[9]*256 );
        if(act_torque[cnt-1] > 30000){act_torque[cnt-1] = act_torque[cnt-1] - 65536;}
        act_torque[cnt-1] = act_torque[cnt-1]*0.02;
        // printf("Motor %d position: %.3f\n",cnt,act_position[0]);
        // if(cnt == 1)
        // tf_current(tmp_current, p[cnt-1], p[cnt-1]+1);//将电流数据转化为两个字节便于发送 u8 为一个字节
        // else
        // tf_current(-tmp_current, p[cnt-1], p[cnt-1]+1);//将电流数据转化为两个字节便于发送 u8 为一个字节
        ec_slave[cnt].outputs[0] = (int)tmp_current;
        ec_slave[cnt].outputs[1] = tmp_current/256;
        // tmp_current = 0;
        usleep(10000);
        // printf("tmp_current:%f\n",tmp_current);
         tmp_current = 0;
        // cin >> tmp_current;

      }

      // (void)signal(SIGINT, ctrl_c_function);
      // if(stop_all) break;
      //   std::cin >> tmp_current;
      //   std::cout<< "set::"<<tmp_current << std::endl;
      // usleep(100000);
    }

      // remaining_time = 260 - timer_ecat.end();
      // if(remaining_time > 0)
      // { 
      //   req = {0, 1000*remaining_time - 50000};
      //   nanosleep(&req, &rem);
      //   remaining_time = timer_ecat.end();
      //   // std::cout<<"ethercat loop: "<<remaining_time<< " us "<<std::endl;
      // }
    for(int cnt = 1; cnt <= ec_slavecount ; cnt++)
    {
      tf_current(0.0, p[cnt-1], p[cnt-1]+1);
    }
    ec_send_processdata();
    ec_receive_processdata(EC_TIMEOUTRET);
    usleep(10000);
    std::cout << "ecat_run end" << std::endl;
    return ;
}