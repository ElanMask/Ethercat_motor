#ifndef _ETHER_CAT_HPP
#define _ETHER_CAT_HPP
#include <stdio.h>
#include <cstdlib>
#include <sys/time.h>
#include <unistd.h>
#include <sched.h>
#include <cstring>
#include <ctime>
#include <fstream>
#include <semaphore.h>
#include <cmath>
#include <pthread.h>
#include <math.h>
#include <iostream>
#include <vector>
#include <csignal>
#include "ethercat.h"
extern bool stop_all; 
void motor_driver_config( bool *stop_all);
void init_motor();
void run_ecat(float current);
#endif